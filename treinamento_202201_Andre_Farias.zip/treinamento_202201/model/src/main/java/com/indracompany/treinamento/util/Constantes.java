package com.indracompany.treinamento.util;

public class Constantes {


	public static final String PARAM_SIS_URL_MIGRA_AUTENTICACAO = "urlMigracaoAutenticacao";
	public static final String PARAM_SIS_URL_MIGRA_TASK = "urlMigracaoTask";
	public static final String PARAM_SIS_URL_MIGRA_REPOS = "urlMigracaoRepos";
	public static final String PARAM_SIS_URL_PROXY = "urlProxy";
	public static final String PARAM_SIS_PORTA_PROXY = "portaProxy";
	public static final String PARAM_SIS_USER_PROXY = "userProxy";
	public static final String PARAM_SIS_PASSWORD_PROXY = "passwordProxy";
	public static final String USER_DOMAIN_EMAIL = "@indracompany.com";
	public static final String USUARIO_LOGADO = "usuarioLogado";
	
}
