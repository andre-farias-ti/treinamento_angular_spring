package com.indracompany.treinamento.model.dto;


import lombok.Data;

@Data
public class ClienteDTO {

	private String nome;
	
	private String email;
	

}
